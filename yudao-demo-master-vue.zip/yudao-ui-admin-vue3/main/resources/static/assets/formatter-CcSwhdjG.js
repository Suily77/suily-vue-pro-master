import{aC as l,__tla as r}from"./index-Daqg4PFz.js";let t,s=Promise.all([(()=>{try{return r}catch{}})()]).then(async()=>{t=(_,e,a,o)=>`\uFFE5${l(a)}`});export{s as __tla,t as f};
