package cn.iocoder.ui.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * UI 的配置类
 *
 * @author 芋道源码
 */
@Configuration(proxyBeanMethods = false)
public class UiConfiguration implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 管理后台 Vue3 的配置
        registry.addResourceHandler("/**", "/")
                .addResourceLocations("classpath:/static/")
                // 自定义 ClassPathResource 实现类，在前端请求的地址匹配不到对应的路径时，强制使用 /index.html 资源
                // 本质上，等价于 nginx 在处理不到 Vue 的请求地址时，try_files 到 index.html 地址
                .addResourceLocations(new ClassPathResource("/static/index.html") {

                    @Override
                    public Resource createRelative(String relativePath) {
                        return this;
                    }

                })
        ;

    }


}
